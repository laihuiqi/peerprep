import React from 'react'

export const Question = (question) => {
  return (
    <div className="question">
        <div className="q-header">
            <div className="q-id">#{question.id}</div>
            <div className="q-title">{question.title}</div>
        </div>
        <div className="tags">
            <div className="q-tag">{question.difficulty}</div>
            <div className="q-tag">{question.topic}</div>
        </div>
        <div className="q-description">{question.description}</div>
    </div>
  )
}
